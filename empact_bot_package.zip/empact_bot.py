
from telegram import Update, ForceReply
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, ContextTypes, filters
import re
import os
from dotenv import load_dotenv

load_dotenv()
TOKEN = os.getenv("EMPACT_BOT_TOKEN")

CONFLICT_WORDS = {
    "тупий": "неконструктивний",
    "ненавиджу": "не підтримую",
    "дурень": "людина з іншою точкою зору",
    "вбити": "зупинити будь-якими методами",
    "підірвати": "нейтралізувати"
}

def soften_text(text: str) -> str:
    for word, replacement in CONFLICT_WORDS.items():
        pattern = re.compile(rf'\b{word}\b', re.IGNORECASE)
        text = pattern.sub(replacement, text)
    return text

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text("Привіт! Надішли мені текст, і я допоможу переформулювати його в мирний варіант.")

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_input = update.message.text
    softened = soften_text(user_input)
    await update.message.reply_text(f"🕊️ Переформульовано:\n{softened}")

if __name__ == '__main__':
    app = ApplicationBuilder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    print("Bot is running...")
    app.run_polling()
