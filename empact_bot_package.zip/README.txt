
# EMPACT Telegram Bot

Цей бот автоматично переформульовує конфліктні фрази в більш мирний варіант.

## Як запустити:

1. Встановити залежності:
   pip install python-telegram-bot python-dotenv

2. Створити `.env` файл і вставити свій токен:
   EMPACT_BOT_TOKEN=your_token_here

3. Запустити:
   python empact_bot.py
